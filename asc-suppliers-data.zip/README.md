# ASC Suppliers Data

Этот репозиторий автоматически собирает свежий список поставщиков рыбы с сайта ASC Aqua.

Файл `asc-suppliers.json` обновляется каждый день в 9:00 UTC.

## Как использовать

Ссылка на сырой JSON (после загрузки репозитория на GitHub):

```
https://raw.githubusercontent.com/ТВОЙ_АККАУНТ/asc-suppliers-data/main/asc-suppliers.json
```
